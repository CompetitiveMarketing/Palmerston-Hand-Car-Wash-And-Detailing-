# Palmerston Hand Car Wash & Detailing — Website Draft

This is a single-file GitHub Pages-ready website.

## Before publishing
1. Replace the photo placeholders with the business's own approved photos.
2. Confirm the exact business location — the public listing I found places this business at Crosby St, Zuccoli NT 0832 (Palmerston/Darwin area), not Alice Springs.
3. Confirm the owner's exact service names, inclusions, prices and preferred booking/contact method.
4. Replace the review placeholder with verified review text only.
5. Confirm phone number and opening hours before launch.

## Publish
Upload `index.html` to the root of a GitHub repository and enable GitHub Pages from the `main` branch / root.
